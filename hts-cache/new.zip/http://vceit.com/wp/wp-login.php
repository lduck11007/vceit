<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-AU">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-AU">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; VCE IT Lecture Notes by Mark Kelly &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='dashicons-css'  href='http://vceit.com/wp/wp-includes/css/dashicons.min.css?ver=0360611ccebca7c9f53642f61982dc0f' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='http://vceit.com/wp/wp-includes/css/buttons.min.css?ver=0360611ccebca7c9f53642f61982dc0f' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='http://vceit.com/wp/wp-admin/css/forms.min.css?ver=0360611ccebca7c9f53642f61982dc0f' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='http://vceit.com/wp/wp-admin/css/l10n.min.css?ver=0360611ccebca7c9f53642f61982dc0f' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://vceit.com/wp/wp-admin/css/login.min.css?ver=0360611ccebca7c9f53642f61982dc0f' type='text/css' media='all' />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//vceit.com/wp/?wordfence_lh=1&hid=050DDD0E618CAA5B48611328A31A35E5');
</script>	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-au">
		<div id="login">
		<h1><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
	<form name="loginform" id="loginform" action="http://vceit.com/wp/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
			<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
				<input type="hidden" name="redirect_to" value="http://vceit.com/wp/wp-admin/" />
					<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>

			<p id="nav">
					<a href="http://vceit.com/wp/wp-login.php?action=lostpassword">Lost your password?</a>
				</p>
	
	<script type="text/javascript">
	function wp_attempt_focus(){
	setTimeout( function(){ try{
			d = document.getElementById('user_login');
				d.focus();
	d.select();
	} catch(e){}
	}, 200);
	}

			wp_attempt_focus();
			if(typeof wpOnload=='function')wpOnload();
			</script>

			<p id="backtoblog"><a href="http://vceit.com/wp/">
		&larr; Back to VCE IT Lecture Notes by Mark Kelly	</a></p>
			
	</div>

	
		<div class="clear"></div>
	</body>
	</html>
	
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: vceit.com @ 2019-09-18 20:06:42 by W3 Total Cache
-->